
############################################################################################## GLOBALS THAT YOU NEED TO FILL IN #################################################################################
#REQUIRED:
authPassword = "H3r#1sAg00dP@ss!" #This password below needs to match exactly what you typed into the on premise server. 
portNumber = "50010" #Most people can leave this at 50010 unless you changed this.
publicIPV4 = "74.76.80.160" #This is just a place holder, you need to enter in your public address from whatismyip.com
############################################################################################# DON'T TOUCH BELOW THIS POINT ######################################################################################


import requests as api
import urllib3
import datetime
import time
import hashlib
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

######################################################### RESPONSES ######################################################


def build_speechlet_response(title, body, output, reprompt_text, should_end_session):
    if reprompt_text == "No":
        return {
            'outputSpeech': {
                'type': 'PlainText',
                'text': output
            },
            'card': {
                'type': 'Simple',
                'title': title,
                'content': body
            },
            'shouldEndSession': should_end_session
        }
    else:
        return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title': title,
            'content': body
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }

def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


########################################################## AUTH ROUTER ##################################################################################################

def AuthRouter(intent, session):
    intent_name = intent['name']
    intent_confirmation = intent['confirmationStatus']
    intent_slots = ""
    slotData = ""
    global authPassword
    global portNumber
    global publicIPV4
    try:
        intent_slots = intent['slots']
        print("Slot data this time:",slotData)
        print(len(intent_slots))
    except:
        print("No Slot Data This Time.")
        print(len(intent_slots))
    
    if len(intent_confirmation) > 0:
        if "Restart" in intent_name:
            tempName = "Restart"
        elif "Shut" in intent_name:
            tempName = "Shutdown"
        else:
            tempName = "Unknown"
        card_title = "My Computer - Canceling {}".format(tempName)
        body_output = "Bye for now."
        speech_output = "Canceling {} on your computer".format(tempName)
        reprompt_text = "No"
        should_end_session = True
        print("LENGTH OF INTENT CONFIRMATION greater than 0" )
        intent_confirmation = intent_confirmation.lower()
        if intent_confirmation == "denied":
            #user said no to confirmation dialogue
            return build_response({}, build_speechlet_response(card_title, body_output, speech_output, reprompt_text, should_end_session))
            response.close()       
            
            
        
    now = datetime.datetime.utcnow()

    
    #Current Min Seed
    seedValue = str(now.year) + str(now.month) + str(now.day) + str(now.hour) + str(now.minute)
    seedValue = authPassword + seedValue

    #Next Min Seed
    nextMin = str(now.minute + 1)
    nextSeedvalue = str(now.year) + str(now.month) + str(now.day) + str(now.hour) + nextMin
    nextSeedvalue = authPassword + nextSeedvalue
    AuthSignature = str(hashlib.sha256(seedValue.encode()).hexdigest()) + "," + str(hashlib.sha256(nextSeedvalue.encode()).hexdigest())
    
    #Constants
    headers = {"AuthKeys": AuthSignature}
    intent = "Intent:" + intent_name + "," +"Slot:" + slotData
    intent = intent.encode().decode()
    print("Passing Intent Data:",intent)
    card_title = "My Computer - " + intent_name
    reprompt_text = "No"
    should_end_session = False
    try:
        #sending down data
        print("Sending down body:",intent)
        print("Sending down headers:",headers)
        response = api.post("https://{}:{}/AuthMe".format(publicIPV4,portNumber),data=intent,headers=headers,timeout=5,verify=False)
        returnedData = response.content
        #to kill the byte arrays
        returnedData = response.content.decode()
        #Decide how to handle session
        if returnedData.startswith("EndSess-"):
            returnedData = returnedData.replace("EndSess-","")
            print("Setting session end state to True, replace EndSess-:", returnedData)
        #Decide how to return 
        if returnedData.startswith("Good"):
            print("Good API Response",returnedData)
            returnedData = returnedData.replace("Good-","")
            body_output = returnedData
            speech_output = returnedData
            return build_response({}, build_speechlet_response(card_title, body_output, speech_output, reprompt_text, should_end_session))
            response.close()
        else:
            print("Bad API Response",returnedData)
            #Add check for auth failures where return needs to contain html data for web page.
            if "<title>" in returnedData:
                #found html tag from title - You Have Been Logged
                returnedData = "Error during auth function. This is likely related to a problem with one of the hash keys, see email for more details."
            else:
                returnedData = returnedData.replace("Bad-","Problem with command. ")
            body_output = returnedData
            speech_output = returnedData
            return build_response({}, build_speechlet_response(card_title, body_output, speech_output, reprompt_text, should_end_session))
            response.close()
    except Exception as E:
        print("Bad API Response",E)
        returnedData = "No response from server! Computer appears to be offline."
        body_output = returnedData
        speech_output = returnedData
        should_end_session = True
        return build_response({}, build_speechlet_response(card_title, body_output, speech_output, reprompt_text, should_end_session))
        response.close()

#################################################################### HANDLERS ########################################################################################
def get_welcome_response():
    # """ If we wanted to initialize the session to have some attributes we could
    # add those here
    # """
    card_title = "My Computer - Ready"
    body_output = "Ready."
    speech_output = "Ready."
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "I am waiting for your input, please tell me what to do."
    should_end_session = False
    return build_response({}, build_speechlet_response(card_title, body_output, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    print("IN HANDLE SESSION END REQUEST FUNCTION")
    card_title = "My Computer - Bye For Now"
    body_output = ""
    speech_output = ""
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(card_title, body_output, speech_output, speech_output, should_end_session))

def handle_session_end_request_Error():
    print("IN HANDLE SESSION END REQUEST ERROR FUNCTION")
    card_title = "My Computer - I am sorry!"
    body_output = "I had trouble understanding you. Please restate your intent."
    speech_output = "I had trouble understanding you. Please restate your intent."
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    return build_response({}, build_speechlet_response(card_title, body_output, speech_output, speech_output, should_end_session))

def handle_session_end_request_Fallback():
    print("IN HANDLE SESSION END REQUEST FALLBACK FUNCTION")
    card_title = "My Computer - I am sorry!"
    body_output = "I had trouble understanding you. Please restate your intent."
    speech_output = "I had trouble understanding you. Please restate your intent."
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    return build_response({}, build_speechlet_response(card_title, body_output, speech_output, speech_output, should_end_session))

#####################################################  Events ################################################################################################

def on_session_started(session_started_request, session):
    # """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session):
    # """ Called when the user launches the skill without specifying what they
    # want
    # """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    
    # Dispatch to your skill's launch
    return get_welcome_response()


def on_intent(intent_request, session):
    # """ Called when the user specifies an intent for this skill """

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    print("Request ID = " + intent_request['requestId'] + " | Session ID = " + session['sessionId'] + " | Intent Has Been Matched To = " + intent_name)

    # Dispatch to your skill's intent handlers
    if intent_name == "StartOver":
    	#we fake a start of skill
        return get_welcome_response()
    elif intent_name == "AMAZON.FallbackIntent":
        return handle_session_end_request_Fallback()  
    elif intent_name == "AMAZON.HelpIntent":
        return get_welcome_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    elif intent_name == "AMAZON.StartOverIntent":
        return get_welcome_response() 
    else:
        #if we dont match any of the above we send to authrouter
        return AuthRouter(intent, session)

def on_session_ended(session_ended_request, session):
    # """ Called when the user ends the session.

    # Is not called when the skill returns should_end_session=true
    # """
    print("on_session_ended requestId=" + session_ended_request['requestId'] + ", sessionId=" + session['sessionId'])
    print("USER SAID EXIT TRYING TO RETURN VALUE")
    # add cleanup logic here
    return handle_session_end_request()    




#################################################### MAIN HANDLER ######################################################################################
    
def lambda_handler(event, context):
    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},event['session'])
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
    else:
        return on_session_ended(event['request'], event['session'])
